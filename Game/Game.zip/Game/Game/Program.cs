﻿using System;
using System.Threading;
using EZInput;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Game
{
    class Program
    {
        static void Main(string[] args)
        {
            // Loop variable
            bool GameRunning = true;

            // Player Coordinates
            int Player_X = 20;
            int Player_Y = 20;

            // Cannival Coordinates
            int Cannibal_X = 43;
            int Cannibal_Y = 54;

            // Lion Coordinates
            int Lion_X = 34;
            int Lion_Y = 65;

            // Snake Coordinates
            int Snake_X = 33;
            int Snake_Y = 54;

            // Bullet Coordinates(Array)
            int[,] Bullets_Left = new int[6,2];
            int[,] Bullets_Right = new int[6,2];
            int[,] Bullets_Down = new int[6,2];
            int[,] Bullets_Up = new int[6,2];


            // Start Menu

            string option;

            Console.WriteLine("1. Start a new Game          ");
            Console.WriteLine("2. Resume previous Game      ");
            Console.WriteLine("3. Exit                  \n\n");
            Console.Write("Enter option:                    ");
            option = Console.ReadLine();

            if(option == "2")
            {
                // LoadData();
            }

            else if(option == "3")
            {
                // Exit
            }

            // Setting Screen 

            /*
            PrintMaze();
            PrintPlayer(Player_X, Player_Y);
            PrintCannibal(Cannibal_X, Cannibal_Y);
            PrintLion(Lion_X, Lion_Y);
            PrintSnake(Snake_X, Snake_Y); 
            */

            // Game Loop

            if(option == "1" || option == "2")
            {
                while (GameRunning)
                {
                    PrintHealth();

                    // Player Movemnt

                    if (Keyboard.IsKeyPressed(Key.UpArrow))
                    {
                        movePlayerUp(maze, ref Player_X, ref Player_Y);
                    }
                    if (Keyboard.IsKeyPressed(Key.DownArrow))
                    {
                        movePlayerDown(maze, ref Player_X, ref Player_Y);
                    }
                    if (Keyboard.IsKeyPressed(Key.LeftArrow))
                    {
                        movePlayerLeft(maze, ref Player_X, ref Player_Y);
                    }
                    if (Keyboard.IsKeyPressed(Key.RightArrow))
                    {
                        movePlayerRight(maze, ref Player_X, ref Player_Y);
                    }

                    // Move Bullets

                    MoveBullets(Bullet_X, Bullet_Y);

                    // Enemies Movemnt

                    MoveCannibal(Cannibal_X, Cannibal_Y);
                    MoveLion(Lion_X, Lion_Y);
                    MoveSnake(Snake_X, Snake_Y);
                    
                }

            }
        }



        static void PrintMaze()
        {

        }


        static void MoveBullets(int[,] Bullets_left, int[,] Bullets_Right, int[,] Bullets_Up, int[,] Bullets_Down)
        {
            MoveBullets_Left(Bullets_left);
            MoveBullets_Right(Bullets_Right);
            MoveBullets_Down(Bullets_Down);
            MoveBullets_Up(Bullets_Up);
            
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sign_In_Sign_Up
{
    public class Credentials
    {
        public string username;
        public string password;
    }
}

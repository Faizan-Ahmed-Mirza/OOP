﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sign_In_Sign_Up
{
    class Program
    {
        static void Main(string[] args)
        {
            string option;
            bool apprunning = true;
            int usercount = 0;
            Credentials start = new Credentials();
            Credentials[] Users = new Credentials[10] ;
            for(int i = 0; i < 10; i++)
            {
                Users[i] = start ;
            }


            while (apprunning)
            {
                option = mainmenu();

                if(option == "1")
                {
                    Sign_in(Users , usercount);
                    usercount++;
                }

                if(option == "2")
                {
                    Sign_up(Users , usercount);
                }

                if(option == "3")
                {
                    apprunning = false;
                }

            }
        }

        static string mainmenu()
        {
            string option;
            Console.WriteLine("1. Sign in");
            Console.WriteLine("2. Sign up");
            Console.WriteLine("3. Exit\n\n");
            Console.Write("Select option: ");
            option = Console.ReadLine();
            return option;
        }

        static void Sign_in(Credentials[] Users , int usercount)
        {
            string enteredusername;
            string enteredpassword;
            bool userflag = false;
            bool passwordflag = false;

            Console.Write("Enter Username: ");
            enteredusername = Console.ReadLine();
            Console.Write("Enter Password: ");
            enteredpassword = Console.ReadLine();


            for(int i = 0; i < usercount; i++)
            {
                if(Users[i].username == enteredusername && Users[i].password == enteredpassword)
                {
                    userflag = true;
                    passwordflag = true;
                    Console.WriteLine("Signed in Successfully!");
                    Console.ReadKey();
                    break;
                }
            }

            if(userflag == false || passwordflag == false)
            {
                Console.WriteLine("Invalid Credentials!");
                Console.ReadKey();
            }
        }


        static void Sign_up(Credentials[] Users , int usercount)
        {
            string enteredusername;
            string enteredpassword;

            Console.Write("Enter Username: ");
            enteredusername = Console.ReadLine();
            Console.Write("Enter Password: ");
            enteredpassword = Console.ReadLine();

            Users[usercount].username = enteredusername;
            Users[usercount].password = enteredpassword;

            Console.WriteLine("Signed Up Successfully");
            Console.ReadKey();



        }
    }
}

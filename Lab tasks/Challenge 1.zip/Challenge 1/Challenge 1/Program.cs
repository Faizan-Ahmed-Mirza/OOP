﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int productcount = 0;
            string option;
            bool Apprunning = true;
            Product[] productsarray = new Product[10]; 
            for(int i = 0; i < 10; i++)
            {
                Product s1 = new Product();
                productsarray[i] = s1 ;
            }

            // Application Loop

            while (Apprunning) {
                // Main Menu
                option = Mainmenu();

                // Add product
                if (option == "1")
                {
                    Add_product(productsarray, productcount);
                    productcount ++;
                } 

                // Show products
                if(option == "2")
                {
                    Show_Products(productsarray);
                }

                // Show total worth of store
                if(option == "3")
                {
                    Show_total_worth (productsarray, productcount);
                }

                // Exit
                if(option == "4")
                {
                    Apprunning = false;
                }

            }
            
        }

        static void Add_product(Product[] productarray , int productcount)
        {
            
            // Taking info

            Console.Write("Enter product name :")        ;
            productarray[productcount].productname = Console.ReadLine();
            Console.Write("Enter product id :")          ;
            productarray[productcount].product_id = Console.ReadLine();
            Console.Write("Enter product price :")          ;
            productarray[productcount].productprice = Console.ReadLine();
            Console.Write("Enter product category :")    ;
            productarray[productcount].category = Console.ReadLine();
            Console.Write("Enter product brand name :")  ;
            productarray[productcount].brandname = Console.ReadLine();
            Console.Write("Enter product country :")     ;
            productarray[productcount].country = Console.ReadLine();
        }

        static void Show_Products(Product[] Productsarray)
        {
            Console.WriteLine("   Name               ID                Category                   Brand            Price               Country\n\n");
            for (int i = 0 ;  i < 10 ; i++)
            {
                Console.WriteLine($" {Productsarray[i].productname}               {Productsarray[i].product_id}                {Productsarray[i].category}                   {Productsarray[i].brandname}            {Productsarray[i].productprice}               {Productsarray[i].country}");

            }

            Console.Write("Press any key to continue....");
            Console.ReadKey();

        }


        static void Show_total_worth(Product[] productarray , int productcount)
        {
            int totalworth = 0;
            for(int i = 0; i < productcount; i++)
            {
                totalworth = totalworth + int.Parse(productarray[i].productprice);

            }

            Console.WriteLine("Total Woth of Store is:  {0}", totalworth);
            Console.Write("Press any key to continue....");
            Console.ReadKey();


        }


        static string Mainmenu()
        {
            string option;
            Console.WriteLine("1. Add Product");
            Console.WriteLine("2. Show Products");
            Console.WriteLine("3. Total Store Worth");
            Console.WriteLine("4. Exit\n\n");
            Console.Write("Select option: ");
            option = Console.ReadLine();

            return option;

        }
    }

}

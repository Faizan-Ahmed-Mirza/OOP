﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Challenge_1
{
    public class Product
    {
        public string productname = "";
        public string productprice= "";
        public string category = "";
        public string brandname = "";
        public string country = "";
        public string product_id = "";
    }
}

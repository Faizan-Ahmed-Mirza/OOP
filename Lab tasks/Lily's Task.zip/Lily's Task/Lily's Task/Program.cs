﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lily_s_Task
{
    class Program
    {
        static void Ismoneyenough(int age , float toyprice , float machineprice)
        {
            float totalmoney = 0F;
            for(int i = 1; i <= age; i++)
            {
                if(i%2 == 0)
                {
                    totalmoney = totalmoney + (10*(i/2)) - 1 ;
                }
                else
                {
                    totalmoney = totalmoney + toyprice;
                }
            }

            if(totalmoney >= machineprice)
            {
                Console.WriteLine($" Yes! She has {totalmoney-machineprice} USD left!");
            }
            else
            {
                Console.WriteLine($" No! She lacks {-totalmoney+machineprice} USD!");
            }
        }


        static void Main(string[] args)
        {
            int age;
            float machinprice;
            float toyprice;

            Console.Write("Enter Lily's Age: ");
            age = int.Parse(Console.ReadLine());

            Console.Write("Enter each toy's price: ");
            toyprice = int.Parse(Console.ReadLine());
            
            Console.Write("Enter machine price: ");
            machinprice = int.Parse(Console.ReadLine());

            Ismoneyenough(age, toyprice, machinprice);

            string[] names = new string[age];
            for (int i = 0; i < age; i++)
            {
                Console.Write($"Enter {i + 1}th name: ");
                names[i] = Console.ReadLine();
            }

            for(int i = 0; i < age; i++)
            {
                Console.WriteLine(names[i]);
            }

            Console.ReadLine();

        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application
{
    public class User
    {
        public string username;
        public string password;
        public string usertype;
        public string Cnic;
        public string Phone_no;
        public string Rent;
        public string Food_charges;
        public string Room_no;
        public string Date;
    }
}

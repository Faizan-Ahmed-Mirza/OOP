﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bussiness_Application
{
    class Program
    {
        static void Main(string[] args)
        {
            // List of user
            List<User> userlist = new List<User>() ;

            // Load Data
            
            Load(userlist);


            // Checking if an admin is already present
            if (!checkadminavailability(userlist)) 
            {
                Addfirstbootadmin(userlist);
            }

            // Local Variables

            string option ;
            int userindex;
            bool Runtime = true;


            
            // Application Runtime Loop

            while (Runtime) 
            {
                // Main menu

                option = mainmenu();
                if (option == "1")
                {
                    userindex = Signin(userlist);
                    if (userindex == 999)
                    {
                        continue ;
                    }

                    // User menu

                    else if(userlist[userindex].usertype == "USER")
                    {
                        option = Usermenu();

                        if(option == "7")
                        {
                            showuserinfo(userindex, userlist);
                        }
                        else if(option == "8")
                        {
                            remove_deleteuser(userlist);
                        }
                        else if(option == "9")
                        {
                            break;
                        }
                    }

                    // Admin Menu

                    else if(userlist[userindex].usertype == "ADMIN")
                    {
                        option = Adminmenu(userlist[userindex].username) ;

                        if(option == "0")
                        {
                            continue;
                        }
                        else if(option == "1")
                        {
                            showuserinfo(userindex, userlist);
                        }
                        else if(option == "2")
                        {
                            remove_deleteuser(userlist);
                        }
                        else if(option == "3")
                        {
                            break;
                        }
                    }
                }
                if(option == "2")
                {
                    SignUp(userlist);
                    Store(userlist);
                }

                if(option == "3")
                {
                    Store(userlist);
                    System.Environment.Exit(1);
                }
            }
        }






        static string mainmenu()
        {
            string option ;
            Console.WriteLine("1. Sign In");
            Console.WriteLine("2. Sign Up");
            Console.WriteLine("3. Exit \n\n");
            Console.Write("Enter option :");
            option = Console.ReadLine();
            return option;
        }





        static string Usermenu()
        {
            string option;

            Console.WriteLine("          ---User Interface---       \n\n");
            Console.WriteLine("0. Return.                               ") ;
            Console.WriteLine("1. Select food plan.                     ") ;
            Console.WriteLine("2. Submit a complaint.                   ") ;
            Console.WriteLine("3. See available rooms.                  ") ;
            Console.WriteLine("4. See your total payable.               ") ;
            Console.WriteLine("5. Check date of your joining.           ") ;
            Console.WriteLine("6. Change username/password.             ") ;
            Console.WriteLine("7. View your information.                ") ;
            Console.WriteLine("8. Delete account.                       ") ;
            Console.WriteLine("9. Exit.                               \n") ;

            option = Console.ReadLine();

            return option;
        }




        static string Adminmenu(string name)
        {
            string option;

            Console.WriteLine("---Admin Panal---                      \n\n");
            Console.WriteLine($"               ----Welcome! {name}----\n\n");
            Console.WriteLine("0. Return.                                 ");
            Console.WriteLine("1. See your info.                          ");
            Console.WriteLine("2. Remove a user/admin.                    ");
            Console.WriteLine("3. Exit.                                   ");


            option = Console.ReadLine();
            return option;
        }




        static bool checkadminavailability(List<User> userlist)
        {
            for(int i = 0; i < userlist.Count; i++)
            {
                if(userlist[i].usertype == "ADMIN")
                {
                    return true;
                }
            }

            return false;
        }





        static int Signin(List<User> userlist)
        {
            string enteredusername;
            string enteredpassword;

            // Taking inputs(Username)

            Console.WriteLine("Enter 00 to return.\n");
            Console.Write("Enter Username: ");
            enteredusername = Console.ReadLine();

            // Return to main menu

            if(enteredusername == "00")
            {
                return 999 ;
            }

            // Password

            Console.Write("Enter Password: ");
            enteredpassword = Console.ReadLine();

            // Checking Username and Password

            for(int index = 0; index < userlist.Count; index++)
            {
                if(enteredusername == userlist[index].username && enteredpassword == userlist[index].password)
                {
                    return index ;
                }
            }

            // For wrong input

            usernotfound() ;
            return Signin(userlist);

        }






        static void SignUp(List<User> userlist)
        {
            // Making object for user

            User objectundercheck = new User();
            objectundercheck = takeinputsfornewuser();
            string adminvaliditynote;

            // Return to mainmenu

            if (objectundercheck == null)
            {
                return;
            }

            // User already Registered

            if (CheckUserExistance(objectundercheck.username , userlist))
            {
                useralreadyexists();
                SignUp(userlist);
                return;
            }

            // Admin verification

            adminvaliditynote = checkadminvalidity(userlist);

            // Return to main menu

            if(adminvaliditynote == "back")
            {
                return;
            }

            // Admin not valid

            if(adminvaliditynote == "absent")
            {
                usernotfound();
                SignUp(userlist);
                return;
            }

            

            // Add user

            userlist.Add(objectundercheck);
            Console.WriteLine("Signed Up Successfully!");
            pause();
        }




        static void usernotfound()
        {
            Console.WriteLine("User not found!");
            pause();
        }




        static bool CheckUserExistance(string usernametocheck, List<User> userlist)
        {
            for(int i = 0; i < userlist.Count ; i++)
            {
                if(userlist[i].username == usernametocheck)
                {
                    return true;
                }
            }

            return false ;
        }




        static void Store(List<User> userlist)
        {

            StreamWriter file = new StreamWriter("C:\\Users\\AIMS TECH\\source\\repos\\Bussiness Application\\Bussiness Application\\Data", false);
            
            for (int i = 0; i < userlist.Count; i++)
            {
                if (userlist[i].usertype == "USER")
                {
                    file.WriteLine($"{userlist[i].username},{userlist[i].password},{userlist[i].usertype},{userlist[i].Cnic},{userlist[i].Date},{userlist[i].Phone_no},{userlist[i].Rent},{userlist[i].Food_charges},");
                }
                else
                {
                    file.WriteLine($"{userlist[i].username},{userlist[i].password},{userlist[i].usertype},");
                }
            }

            file.Close();

        }




        static void useralreadyexists()
        {
            Console.WriteLine("Username already registered. Please enter a different username!");
            pause();
        }





        static void Load(List<User> userlist)
        {

            string line;
            int commacount = 0;

            StreamReader file = new StreamReader("C:\\Users\\AIMS TECH\\source\\repos\\Bussiness Application\\Bussiness Application\\Data");

            for(int index = 0; ((line = file.ReadLine()) != null); index++)
            {

                for (int i = 0; i < line.Length; i++)
                {
                    // Comma Count

                    if(line[i] == ',')
                    {
                        commacount ++;
                    }

                    // Username

                    if (line[i] != ',' && commacount == 0)
                    {
                        userlist[index].username = userlist[index].username + line[i];
                    }

                    // Password

                    if (line[i] != ',' && commacount == 1)
                    {
                        userlist[index].password = userlist[index].password + line[i];
                    }

                    // User Type

                    if (line[i] != ',' && commacount == 2)
                    {
                        userlist[index].usertype = userlist[index].usertype + line[i];
                    }


                    if(userlist[index].usertype == "USER")
                    {

                        // Cnic

                        if (line[i] != ',' && commacount == 3)
                        {
                            userlist[index].Cnic = userlist[index].Cnic + line[i];
                        }

                        // Date

                        if (line[i] != ',' && commacount == 4)
                        {
                            userlist[index].Date = userlist[index].Date + line[i];
                        }

                        // Phone number

                        if (line[i] != ',' && commacount == 5)
                        {
                            userlist[index].Phone_no = userlist[index].Phone_no + line[i];
                        }

                        // Rent

                        if (line[i] != ',' && commacount == 5)
                        {
                            userlist[index].Rent = userlist[index].Rent + line[i];
                        }

                        // Food Charges

                        if (line[i] != ',' && commacount == 6)
                        {
                            userlist[index].Food_charges = userlist[index].Food_charges + line[i];
                        }
                    }

                }

            }

            file.Close();

        }





        static void showuserinfo(int userindex, List<User> userlist)
        {
            Console.WriteLine(" Your Information: \n\n");
            Console.WriteLine($"Username:                     {userlist[userindex].username}")    ;
            Console.WriteLine($"Password:                     {userlist[userindex].password}")    ;
            Console.WriteLine($"Phone number:                 {userlist[userindex].Phone_no}")     ;
            Console.WriteLine($"Room no:                      {userlist[userindex].Room_no}")      ;
            Console.WriteLine($"CNIC:                         {userlist[userindex].Cnic}")        ;
            Console.WriteLine($"Rent:                         {userlist[userindex].Rent}")        ;
            Console.WriteLine($"Food Charges:                 {userlist[userindex].Food_charges}") ;
            Console.WriteLine($"Date if joining:              {userlist[userindex].Date}")        ;


            pause();

        }




        static void showinvalidinput()
        {
            Console.WriteLine("Invalid input! Please enter a valid input.");
            Console.WriteLine("Press any key to continue....");
            Console.ReadKey();
        }





        static User takeinputsfornewuser()
        {

            // Local variables

            string enteredusername = "";
            string enteredpassword = "";
            string enteredusertype = "";
            string enteredcnic = "";
            string enteredrent = "";
            string entereddate = "";
            string enteredroom_no = "";
            string enteredphone_no = "";
            string enteredfoodcharges = "";

            // Making object from user class

            User newuser = new User();

            // Taking inputs:

            Console.WriteLine("Enter 00 to return.");
            Console.Write("Enter username:   ");
            enteredusername = Console.ReadLine();

            // Return option
            if(enteredusername == "00")
            {
                return null;
            }

            Console.Write("Enter password:   ");
            enteredpassword = Console.ReadLine();
            Console.Write("Enter usertype (admin/user):   ");
            enteredusertype = Console.ReadLine().ToUpper();

            // Client

            if (enteredusertype == "USER")
            {
                Console.Write("Enter CNIC:   ");
                enteredcnic = Console.ReadLine();
                Console.Write("Enter Phone number(11-digits):   ");
                enteredphone_no = Console.ReadLine();
                Console.Write("Enter Room no:   ");
                enteredroom_no = Console.ReadLine();
                Console.Write("Enter Rent for Client:   ");
                enteredrent = Console.ReadLine();
                Console.Write("Enter Food Charges:   ");
                enteredfoodcharges = Console.ReadLine();
                Console.Write("Enter date of joining:   ");
                entereddate = Console.ReadLine();
            }

            else if(enteredusertype == "ADMIN")
            {

            }

            else
            {
                showinvalidinput();
                return null ;
            }

            // Filling object attributes

            newuser.Food_charges = enteredfoodcharges;
            newuser.username = enteredusername;
            newuser.password = enteredpassword;
            newuser.usertype = enteredusertype;
            newuser.Phone_no = enteredphone_no;
            newuser.Room_no = enteredroom_no;
            newuser.Cnic = enteredcnic;
            newuser.Rent = enteredrent;
            newuser.Date = entereddate;

            // Return object

            return newuser ;
        }




        static string checkadminvalidity(List<User> userlist)
        {
            int userindex;
            Console.WriteLine("Enter username/password of a former admin for verification\n\n");


            userindex = Signin(userlist);

            if(userindex == 999)
            {
                return "back" ;
            }

            if(userlist[userindex].usertype == "ADMIN")
            {
                return "present" ;
            }

            // if not valid former admin

            return "absent" ;

        }



        static void Addfirstbootadmin(List<User> userlist)
        {
            User firstbootadmin = new User();

            firstbootadmin.username = "Faizan";
            firstbootadmin.password = "MirZa";
            firstbootadmin.usertype = "ADMIN";

            userlist.Add(firstbootadmin);

        }


        static void pause()
        {
            Console.Write("Please enter any key to continue....");
            Console.ReadKey();
        }



        static void remove_deleteuser(List<User> userlist)
        {
            int userindex;
            Console.WriteLine("Enter username/password to confirm action.\n\n") ;
            userindex = Signin(userlist);

            if(userindex == 999)
            {
                return;
            }

            userlist.RemoveAt(userindex);
            Console.WriteLine("Successfully removed.");
            pause();

        }




    }

}
